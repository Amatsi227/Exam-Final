﻿namespace convertisseur
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int pouces;

            saisirEntierPositif(pouces);
            afficherPiedEnPouce(pouces);
            afficherEnCentimetre(pouces);
            afficherEnMetre(pouces);
        }

        // Saisir un entier positif
        static void saisirEntierPositif(int pouces)
        {
            do
            {
                pouces = int.TryParse(Console.Read("Veuillez saisir un entier positif : ") ?? "");
            } while (pouces < 0)
        }

        //^Pouce en Pieds
        static void afficherPiedEnPouce(int pouces) 
        { 
            double pied = pouces / 12;
            Console.WriteLine($"{pouces} Pouces = {pied} pieds");
        }

        //^Pouce en centimetres
        static void afficherEnCentimetre(int pouces) 
        { 
            double centimetre = pouces * 2.54;
            Console.WriteLine($"{pouces} Pouces = {centimetre} centimetres");
        }

        //^Pouce en metres
        static void afficherEnMetre(int pouces) 
        {
            double metre = (pouces * 2.54) / 100;
            Console.WriteLine($"{pouces} Pouces = {metre} metres");
        }
    }
}
